# RoutVia

**Adaptive Smart Mobile App for Tracking and Monitoring of Public Transport**
Application: RoutVia · Transport service: Karachi Red Bus · Free tools only.

## 1. Install
```bash
npm install
```

## 2. Environment (`.env`)
A ready `.env` file is included. Replace every `YOUR_...` value with your own.
`.env.example` is the same file with placeholders only (safe to share). `.env` is git-ignored.
While Firebase values still contain `YOUR_`, the app runs in **Demo Mode** (simulated bus, clearly labelled).
Restart `npm run dev` after editing `.env`.

| Variable | Where to find it |
|---|---|
| `VITE_FIREBASE_*` | Firebase Console > Project settings > Your apps > Web app (`</>`) > Config |
| `VITE_FIREBASE_DATABASE_URL` | Realtime Database > Data tab (URL shown at the top) |
| `VITE_DEV_PORT` | Keep 5173 (must match `ngrok http 5173`) |
| `VITE_ALLOWED_HOST` | Optional extra host for Vite (ngrok domains already allowed) |
| `VITE_DEMO_MODE` | `auto` / `on` / `off` |
| `VITE_AVERAGE_BUS_SPEED_KMH`, `VITE_ROAD_DISTANCE_MULTIPLIER`, ... | Approximate ETA settings |

## 3. Firebase setup (Spark free plan)
1. Console > **Add project** (no billing needed).
2. **Build > Realtime Database > Create database** (start in locked mode).
3. **Build > Authentication > Sign-in method > Anonymous > Enable** (required: rules need `auth != null`).
4. **Project settings > Your apps > Add web app**, copy the config into `.env`.
5. **Realtime Database > Rules**: paste the content of `database.rules.json` and **Publish**.
   (CLI alternative: put your project id in `.firebaserc`, then `firebase deploy --only database`.)
6. Optional: Realtime Database > Data > ⋮ > **Import JSON** > `docs/routes-seed.json` (route data for the `routes/` node).

Rules summary: only signed-in (anonymous) users can read; bus records and Lost & Found reports are validated; Lost & Found is create-only; `routes/` is read-only.
Never put service-account keys in this project. Firebase web config values are not secrets; the rules protect the data.

## 4. Run locally
```bash
npm run dev
```
Open http://localhost:5173

## 5. Ngrok (driver phone over HTTPS)
Browser GPS only works on HTTPS, so the driver phone must use the ngrok link.
1. Install ngrok, then once: `ngrok config add-authtoken YOUR_NGROK_TOKEN`
2. Terminal 1: `npm run dev`
3. Terminal 2: `npm run tunnel` (same as `ngrok http 5173`)
4. Copy the `https://xxxx.ngrok-free.app` URL ngrok prints.
   - Driver phone: `https://xxxx.ngrok-free.app/driver`
   - Passenger laptop: `https://xxxx.ngrok-free.app/` (or localhost)
5. The URL changes on every ngrok restart; nothing is hardcoded. Laptop, dev server and ngrok must stay running.
If you see "Blocked request / host not allowed", add the host to `VITE_ALLOWED_HOST` and restart Vite.

## 6. Test checklist
- [ ] No Firebase keys: app works, Demo Mode label visible
- [ ] Keys added: Firebase auth works (no permission-denied errors in console)
- [ ] Driver: Start Trip > allow GPS > data appears in Realtime Database `buses/BUS001`
- [ ] Passenger: marker moves, ETA updates
- [ ] Stop Trip: status becomes `inactive`
- [ ] Lost & Found report appears in `lostFound/`

OpenStreetMap tiles are used with attribution under the OSM tile usage policy. Respect Firebase Spark quotas.
