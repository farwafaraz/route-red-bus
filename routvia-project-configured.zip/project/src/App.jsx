import { useEffect, useState } from 'react';
import { BrowserRouter, Link, NavLink, Route, Routes, useNavigate, useParams } from 'react-router-dom';
import { CircleAlert, CircleCheck, Clock3, Compass, MapPin, Menu, MessageCircle, Navigation, Play, Search, Send, Square, UserRound, X, Zap } from 'lucide-react';
import { CircleMarker, MapContainer, Polyline, TileLayer, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import { demoItems, getRoute, haversineDistance, routes, routeStops, sampleLocations } from '@/data';
import { settings, shouldStartInDemoMode } from '@/config';
import { firebaseReady, publishBusLocation, publishLostFoundReport, subscribeToBus, subscribeToLostFound } from '@/services/firebase';
const navy = '#082b67';
function Logo() {
    return <Link to="/" className="brand"><span className="brand-mark"><span className="bus-window"/><span className="bus-window"/><span className="bus-wheel left"/><span className="bus-wheel right"/></span><span><strong>RoutVia</strong><small>Karachi Red Bus</small></span></Link>;
}
function Shell({ children, title, subtitle }) {
    return <div className="app-shell"><header className="topbar"><Logo /><div className="topbar-title">{title && <><span>{title}</span>{subtitle && <small>{subtitle}</small>}</>}</div><button className="icon-button" aria-label="Open menu"><Menu size={21}/></button></header>{children}<BottomNav /></div>;
}
function BottomNav() {
    return <nav className="bottom-nav"><NavLink to="/" end><Navigation size={18}/><span>Explore</span></NavLink><NavLink to="/lost-found"><Compass size={18}/><span>Lost & Found</span></NavLink><NavLink to="/assistant"><MessageCircle size={18}/><span>Assistant</span></NavLink><NavLink to="/driver"><UserRound size={18}/><span>Driver</span></NavLink></nav>;
}
function StatusPill({ status }) {
    return <span className={`status-pill ${status.toLowerCase()}`}>{status}</span>;
}
function Home() {
    const [boarding, setBoarding] = useState('Gulshan-e-Iqbal');
    const [destination, setDestination] = useState('North Karachi');
    const [filter, setFilter] = useState('All Routes');
    const navigate = useNavigate();
    const visibleRoutes = routes.filter((route) => filter === 'All Routes' || (filter === 'Active Buses' ? route.status === 'Live' : route.status === 'Scheduled'));
    return <Shell><main className="page home-page"><section className="hero-intro"><div><p className="project-title">Adaptive Smart Mobile App for Tracking and Monitoring of Public Transport</p><p className="eyebrow">Smart Public Transport Tracking</p><h1>Plan your ride<br /><span>with confidence.</span></h1></div><div className="live-badge"><span className="pulse-dot"/> Live network</div></section><section className="search-card"><div className="field-row"><MapPin size={18}/><label>Boarding at<select value={boarding} onChange={(event) => setBoarding(event.target.value)}>{routeStops.map((stop) => <option key={stop}>{stop}</option>)}</select></label><span className="field-chevron">⌄</span></div><div className="field-divider"/><div className="field-row"><Navigation size={18}/><label>Going to<select value={destination} onChange={(event) => setDestination(event.target.value)}>{routeStops.map((stop) => <option key={stop}>{stop}</option>)}</select></label><span className="field-chevron">⌄</span></div></section><div className="section-heading"><div><p className="eyebrow">Karachi Red Bus</p><h2>Routes near you</h2></div><span className="demo-label">Demo information</span></div><div className="filter-row">{['All Routes', 'Active Buses', 'Scheduled Buses'].map((item) => <button key={item} className={`filter-chip ${filter === item ? 'active' : ''}`} onClick={() => setFilter(item)}>{item}</button>)}</div><div className="route-list">{visibleRoutes.map((route) => <RouteCard key={route.id} route={route} onClick={() => navigate(`/tracking/${route.busId}`)}/>)}{visibleRoutes.length === 0 && <div className="empty-state">No scheduled buses are available right now.</div>}</div></main></Shell>;
}
function RouteCard({ route, onClick }) {
    return <button className="route-card" onClick={onClick}><div className="route-line"><span className="route-number">{route.id}</span><span className="route-name">{route.name}</span><StatusPill status={route.status}/></div><div className="route-meta"><span><UserRound size={13}/> {route.busId}</span><span><Clock3 size={13}/> {route.departure}</span></div><div className="route-bottom"><span className="route-path">{route.start} <i>→</i> {route.destination}</span><span className={`eta ${route.status === 'Inactive' ? 'muted' : ''}`}>{route.status === 'Live' ? `Arrives in ${route.eta}` : route.eta}</span></div><span className="view-link">View live tracking <span>↗</span></span></button>;
}
function MapRecenter({ position }) {
    const map = useMap();
    useEffect(() => { map.setView(position, 12, { animate: true }); }, [map, position]);
    return null;
}
function BusMarker({ position }) {
    return <CircleMarker center={position} radius={14} pathOptions={{ color: '#fff', weight: 4, fillColor: '#1477d4', fillOpacity: 1 }}><CircleMarker center={position} radius={5} pathOptions={{ color: '#fff', weight: 2, fillColor: '#1477d4', fillOpacity: 1 }}/></CircleMarker>;
}
function Tracking() {
    const { busId = 'BUS001' } = useParams();
    const route = routes.find((item) => item.busId === busId) ?? routes[0];
    const [location, setLocation] = useState(sampleLocations[route.busId] ?? sampleLocations.BUS001);
    const [demoMode, setDemoMode] = useState(shouldStartInDemoMode);
    const [selectedStop, setSelectedStop] = useState(route.stops[3] ?? route.stops[0]);
    const position = [location.latitude, location.longitude];
    const distance = haversineDistance([location.latitude, location.longitude], [selectedStop.lat, selectedStop.lng]) * settings.roadDistanceMultiplier;
    const usableSpeed = location.speed >= settings.minUsableGpsSpeedKmh ? location.speed : settings.averageBusSpeedKmh;
    const eta = Math.max(1, Math.ceil((distance / usableSpeed) * 60));
    useEffect(() => {
        const unsubscribe = subscribeToBus(route.busId, (next) => { setLocation(next); setDemoMode(false); });
        return unsubscribe;
    }, [route.busId]);
    useEffect(() => {
        if (!demoMode)
            return;
        let step = 0;
        const timer = window.setInterval(() => {
            const stops = route.stops;
            const from = stops[step % (stops.length - 1)];
            const to = stops[(step % (stops.length - 1)) + 1];
            const progress = ((Date.now() / 1000) % 18) / 18;
            setLocation((current) => ({ ...current, latitude: from.lat + (to.lat - from.lat) * progress, longitude: from.lng + (to.lng - from.lng) * progress, lastUpdated: Date.now() }));
            if (progress > 0.98)
                step += 1;
        }, 1800);
        return () => window.clearInterval(timer);
    }, [demoMode, route]);
    return <Shell title="Live tracking" subtitle={`Bus ${route.busId} · ${route.id} — ${route.name}`}><main className="tracking-page"><div className="tracking-map-wrap"><MapContainer center={position} zoom={12} scrollWheelZoom className="tracking-map"><TileLayer attribution='&copy; OpenStreetMap contributors' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/><Polyline positions={route.stops.map((stop) => [stop.lat, stop.lng])} pathOptions={{ color: '#126ac1', weight: 5, opacity: 0.9 }}/>{route.stops.map((stop) => <CircleMarker key={stop.name} center={[stop.lat, stop.lng]} radius={6} pathOptions={{ color: '#fff', weight: 2, fillColor: stop.name === selectedStop.name ? '#ed6a4d' : navy, fillOpacity: 1 }}/>)}<BusMarker position={position}/><MapRecenter position={position}/></MapContainer><div className="map-top-label"><span className="pulse-dot"/> {demoMode ? 'Demo Mode — simulated bus location' : 'Live driver location'}</div><div className="map-controls"><button onClick={() => setSelectedStop(route.stops[(route.stops.findIndex((stop) => stop.name === selectedStop.name) + 1) % route.stops.length])}><Navigation size={17}/></button></div></div><section className="trip-panel"><div className="panel-handle"/><div className="trip-summary"><div><p className="eyebrow">Your selected stop</p><h2>{selectedStop.name}</h2></div><div className="eta-block"><strong>{demoMode ? `${eta} min` : `${eta} min`}</strong><span>approx. arrival</span></div></div><div className="trip-facts"><div><span>Bus ID</span><strong>{route.busId}</strong></div><div><span>Route</span><strong>{route.id} · {route.name}</strong></div><div><span>Distance</span><strong>{distance.toFixed(1)} km</strong></div></div><div className="approx-note"><Zap size={15}/> Estimated arrival — approximate, based on straight-line distance.</div><div className="next-stop"><div><span className="live-dot"/> Next stop</div><strong>{route.stops[(route.stops.findIndex((stop) => stop.name === selectedStop.name) + 1) % route.stops.length].name}</strong></div><div className="stop-list">{route.stops.map((stop, index) => <button key={stop.name} className={`stop-row ${stop.name === selectedStop.name ? 'selected' : ''}`} onClick={() => setSelectedStop(stop)}><span className="stop-dot"/><span>{stop.name}</span>{index < route.stops.findIndex((item) => item.name === selectedStop.name) && <CircleCheck size={15}/>}</button>)}</div></section></main></Shell>;
}
function Driver() {
    const [selectedRoute, setSelectedRoute] = useState(routes[0]);
    const [tracking, setTracking] = useState(false);
    const [gpsStatus, setGpsStatus] = useState('Ready to connect');
    const [lastLocation, setLastLocation] = useState(null);
    const [watchId, setWatchId] = useState(null);
    const startTrip = () => {
        if (!navigator.geolocation) {
            setGpsStatus('GPS is not available on this device');
            return;
        }
        setGpsStatus('Requesting GPS permission…');
        const id = navigator.geolocation.watchPosition(async (position) => {
            const next = { busId: selectedRoute.busId, routeId: selectedRoute.id, latitude: position.coords.latitude, longitude: position.coords.longitude, speed: Math.round((position.coords.speed ?? 0) * 3.6), accuracy: Math.round(position.coords.accuracy), status: 'active', lastUpdated: Date.now() };
            setLastLocation(next);
            setGpsStatus(firebaseReady ? 'Live GPS connected' : 'GPS connected · Firebase not configured');
            setTracking(true);
            await publishBusLocation(next);
        }, (error) => setGpsStatus(error.code === 1 ? 'Location permission was denied' : 'Unable to read your location'), { enableHighAccuracy: true, timeout: 10000, maximumAge: 5000 });
        setWatchId(id);
    };
    const stopTrip = async () => { if (watchId !== null)
        navigator.geolocation.clearWatch(watchId); setWatchId(null); setTracking(false); setGpsStatus('Trip stopped'); if (lastLocation)
        await publishBusLocation({ ...lastLocation, status: 'inactive', lastUpdated: Date.now() }); };
    return <Shell title="Driver panel" subtitle="Your assigned routes"><main className="page driver-page"><div className="driver-welcome"><div><p className="eyebrow">Good morning, driver</p><h1>Ready for the road?</h1></div><span className={`driver-status ${tracking ? 'on' : ''}`}><span className="pulse-dot"/> {tracking ? 'On trip' : 'Offline'}</span></div><label className="select-label">Select your assigned route<select value={selectedRoute.id} onChange={(event) => setSelectedRoute(getRoute(event.target.value))}>{routes.map((route) => <option key={route.id} value={route.id}>{route.id} — {route.name}</option>)}</select></label><section className="assigned-card"><div className="assigned-card-top"><div><span className="route-number large">{selectedRoute.id}</span><h2>{selectedRoute.name}</h2></div><span className="bus-badge">{selectedRoute.busId}</span></div><div className="route-journey"><div><span>Starting point</span><strong>{selectedRoute.start}</strong></div><div className="journey-line"/><div><span>Destination</span><strong>{selectedRoute.destination}</strong></div></div><div className="driver-stops">{selectedRoute.stops.map((stop, index) => <span key={stop.name} className={index === 0 ? 'first' : ''}><i /> {stop.name}</span>)}</div></section><section className="gps-card"><div className="gps-card-heading"><div className="gps-icon"><Navigation size={19}/></div><div><h3>GPS & tracking</h3><p>{gpsStatus}</p></div><span className={`connection-dot ${tracking ? 'connected' : ''}`}/></div>{lastLocation && <div className="coordinates"><span>Current coordinates</span><strong>{lastLocation.latitude.toFixed(5)}, {lastLocation.longitude.toFixed(5)}</strong><small>Accuracy ±{lastLocation.accuracy}m · Updated just now</small></div>}{!tracking ? <button className="primary-button full" onClick={startTrip}><Play size={18} fill="currentColor"/> Start trip</button> : <button className="stop-button full" onClick={stopTrip}><Square size={16} fill="currentColor"/> Stop trip</button>}</section><div className="driver-note"><CircleAlert size={16}/><span>Keep this screen open while driving. GPS works best over a secure HTTPS connection.</span></div></main></Shell>;
}
function LostFound() {
    const [tab, setTab] = useState('All');
    const [items, setItems] = useState(() => { try {
        return [...demoItems, ...JSON.parse(localStorage.getItem('routvia-lost-found') ?? '[]')];
    }
    catch {
        return demoItems;
    } });
    const [showForm, setShowForm] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    useEffect(() => subscribeToLostFound((reports) => {
        const remoteItems = Object.entries(reports).map(([id, report]) => ({ ...report, id }));
        if (remoteItems.length)
            setItems([...demoItems, ...remoteItems]);
    }), []);
    const filtered = items.filter((item) => tab === 'All' || item.type === tab);
    return <Shell title="Lost & Found"><main className="page lost-page"><div className="page-header"><div><p className="eyebrow">Karachi Red Bus network</p><h1>Lost & Found</h1></div><button className="icon-button light"><Search size={19}/></button></div><div className="tabs">{['All', 'Lost', 'Found'].map((item) => <button key={item} className={tab === item ? 'active' : ''} onClick={() => setTab(item)}>{item}<span>{item === 'All' ? items.length : items.filter((report) => report.type === item).length}</span></button>)}</div><div className="item-list">{filtered.map((item) => <article className="item-card" key={item.id}><div className={`item-icon ${item.type.toLowerCase()}`}>{item.type === 'Lost' ? <CircleAlert size={19}/> : <CircleCheck size={19}/>}</div><div className="item-details"><div className="item-title"><h3>{item.itemName}</h3><StatusPill status={item.type}/></div><p>{item.description}</p><span><span className="bus-small">{item.busId}</span> · {item.createdAt}</span></div></article>)}</div><button className="floating-action" onClick={() => setShowForm(true)}>+ Report item</button></main>{showForm && <ReportModal onClose={() => setShowForm(false)} onSubmit={(report) => { void publishLostFoundReport({ ...report, createdAt: 'Just now' }); const next = [...items, { ...report, id: Date.now().toString(), createdAt: 'Just now' }]; setItems(next); localStorage.setItem('routvia-lost-found', JSON.stringify(next.slice(4))); setShowForm(false); setSubmitted(true); window.setTimeout(() => setSubmitted(false), 3000); }}/>}{submitted && <div className="toast"><CircleCheck size={18}/> Report submitted successfully</div>}</Shell>;
}
function ReportModal({ onClose, onSubmit }) {
    const [form, setForm] = useState({ itemName: '', type: 'Lost', busId: '', routeId: 'R9', description: '', contact: '' });
    const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));
    return <div className="modal-backdrop"><section className="modal"><div className="modal-heading"><div><p className="eyebrow">Help reunite an item</p><h2>Report an item</h2></div><button className="icon-button light" onClick={onClose}><X size={19}/></button></div><form onSubmit={(event) => { event.preventDefault(); onSubmit(form); }}><label>Item name<input required value={form.itemName} onChange={(event) => update('itemName', event.target.value)} placeholder="e.g. Black wallet"/></label><div className="form-grid"><label>Status<select value={form.type} onChange={(event) => update('type', event.target.value)}><option>Lost</option><option>Found</option></select></label><label>Bus ID<input required value={form.busId} onChange={(event) => update('busId', event.target.value)} placeholder="BUS001"/></label></div><label>Route number<select value={form.routeId} onChange={(event) => update('routeId', event.target.value)}>{routes.map((route) => <option key={route.id}>{route.id}</option>)}</select></label><label>Description<textarea required value={form.description} onChange={(event) => update('description', event.target.value)} placeholder="Add a few identifying details"/></label><label>Contact information<input required value={form.contact} onChange={(event) => update('contact', event.target.value)} placeholder="Phone or email"/></label><button className="primary-button full" type="submit">Submit report</button></form></section></div>;
}
function Assistant() {
    const [messages, setMessages] = useState([{ role: 'assistant', text: 'Hi, I can help with live buses, routes and approximate arrival times.' }]);
    const [input, setInput] = useState('');
    const answer = (question) => { const text = question.toLowerCase(); const liveRoute = routes[0]; if (text.includes('where') || text.includes('location'))
        return `Bus ${liveRoute.busId} on Route ${liveRoute.id} is currently being tracked in Demo Mode. Open Live Tracking to see its map position.`; if (text.includes('when') || text.includes('arrive') || text.includes('eta'))
        return `The approximate arrival for ${liveRoute.busId} is ${liveRoute.eta}. This estimate uses current speed and straight-line distance.`; if (text.includes('active'))
        return `${routes.filter((route) => route.status === 'Live').length} buses are currently marked active: ${routes.filter((route) => route.status === 'Live').map((route) => route.busId).join(', ')}.`; if (text.includes('next stop'))
        return `The next stop on ${liveRoute.id} is Gulshan-e-Iqbal.`; if (text.includes('r9') || text.includes('route'))
        return 'R9 runs from Saddar through Clifton, Korangi and Gulshan-e-Iqbal toward North Karachi.'; return 'I can help with bus locations, ETAs, active buses, next stops and route information.'; };
    const ask = (question = input) => { if (!question.trim())
        return; setMessages((current) => [...current, { role: 'user', text: question }, { role: 'assistant', text: answer(question) }]); setInput(''); };
    return <Shell title="RoutVia AI Assistant" subtitle="Your guide to Karachi Red Bus"><main className="assistant-page"><div className="assistant-hero"><div className="assistant-avatar"><Zap size={22}/></div><div><p className="eyebrow">Always here to help</p><h1>Ask RoutVia</h1><span>Answers from your live network</span></div><span className="online-label"><span className="pulse-dot"/> Online</span></div><div className="suggestions">{['Where is my bus?', 'When will it arrive?', 'Which buses are active?', 'What is the R9 route?'].map((question) => <button key={question} onClick={() => ask(question)}>{question}</button>)}</div><div className="chat-window">{messages.map((message, index) => <div key={`${message.role}-${index}`} className={`chat-message ${message.role}`}><div className="chat-bubble">{message.text}</div></div>)}</div><form className="chat-input" onSubmit={(event) => { event.preventDefault(); ask(); }}><input value={input} onChange={(event) => setInput(event.target.value)} placeholder="Ask about a bus or route…"/><button aria-label="Send question"><Send size={18}/></button></form><p className="assistant-disclaimer">RoutVia AI uses demo route data when live network information is unavailable.</p></main></Shell>;
}
function App() {
    return <BrowserRouter><Routes><Route path="/" element={<Home />}/><Route path="/tracking/:busId" element={<Tracking />}/><Route path="/driver" element={<Driver />}/><Route path="/lost-found" element={<LostFound />}/><Route path="/assistant" element={<Assistant />}/></Routes></BrowserRouter>;
}
export default App;
