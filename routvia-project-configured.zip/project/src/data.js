export const routes = [
    {
        id: 'R9',
        name: 'Karachi Route',
        busId: 'BUS001',
        departure: '07:30 AM',
        status: 'Live',
        eta: '6 min',
        start: 'Saddar',
        destination: 'North Karachi',
        stops: [
            { name: 'Saddar', lat: 24.8547, lng: 67.0099 },
            { name: 'Clifton', lat: 24.8138, lng: 67.0308 },
            { name: 'Korangi', lat: 24.8142, lng: 67.1247 },
            { name: 'Gulshan-e-Iqbal', lat: 24.9162, lng: 67.0971 },
            { name: 'North Karachi', lat: 24.9924, lng: 67.0647 },
        ],
    },
    {
        id: 'R4',
        name: 'North Karachi Route',
        busId: 'BUS007',
        departure: '07:45 AM',
        status: 'Live',
        eta: '14 min',
        start: 'Clifton',
        destination: 'North Karachi',
        stops: [
            { name: 'Clifton', lat: 24.8138, lng: 67.0308 },
            { name: 'Saddar', lat: 24.8547, lng: 67.0099 },
            { name: 'Gulshan-e-Iqbal', lat: 24.9162, lng: 67.0971 },
            { name: 'North Karachi', lat: 24.9924, lng: 67.0647 },
        ],
    },
    {
        id: 'R2',
        name: 'Clifton Route',
        busId: 'BUS003',
        departure: '08:15 AM',
        status: 'Inactive',
        eta: 'Waiting',
        start: 'Gulshan-e-Iqbal',
        destination: 'Clifton',
        stops: [
            { name: 'Gulshan-e-Iqbal', lat: 24.9162, lng: 67.0971 },
            { name: 'Saddar', lat: 24.8547, lng: 67.0099 },
            { name: 'Clifton', lat: 24.8138, lng: 67.0308 },
        ],
    },
];
export const sampleLocations = {
    BUS001: { busId: 'BUS001', routeId: 'R9', latitude: 24.861, longitude: 67.044, speed: 25, accuracy: 10, status: 'active', lastUpdated: Date.now() },
    BUS007: { busId: 'BUS007', routeId: 'R4', latitude: 24.884, longitude: 67.06, speed: 18, accuracy: 12, status: 'active', lastUpdated: Date.now() },
};
export const demoItems = [
    { id: '1', itemName: 'Black Wallet', type: 'Lost', busId: 'BUS012', routeId: 'R9', description: 'Black leather wallet with cards inside.', contact: 'Contact through RoutVia', createdAt: 'Today · 8:15 AM' },
    { id: '2', itemName: 'Blue Umbrella', type: 'Found', busId: 'BUS007', routeId: 'R4', description: 'Compact blue umbrella left on a seat.', contact: 'Contact through RoutVia', createdAt: 'Today' },
    { id: '3', itemName: 'Student ID Card', type: 'Lost', busId: 'BUS003', routeId: 'R2', description: 'ID card found near the rear entrance.', contact: 'Contact through RoutVia', createdAt: 'Yesterday' },
    { id: '4', itemName: 'Water Bottle', type: 'Found', busId: 'BUS012', routeId: 'R9', description: 'Green reusable bottle with a silver cap.', contact: 'Contact through RoutVia', createdAt: 'Today' },
];
export const routeStops = routes.flatMap((route) => route.stops.map((stop) => stop.name)).filter((stop, index, all) => all.indexOf(stop) === index);
export function getRoute(routeId) {
    return routes.find((route) => route.id === routeId) ?? routes[0];
}
export function haversineDistance(from, to) {
    const earthRadius = 6371;
    const latDelta = ((to[0] - from[0]) * Math.PI) / 180;
    const lngDelta = ((to[1] - from[1]) * Math.PI) / 180;
    const a = Math.sin(latDelta / 2) ** 2 + Math.cos((from[0] * Math.PI) / 180) * Math.cos((to[0] * Math.PI) / 180) * Math.sin(lngDelta / 2) ** 2;
    return earthRadius * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}
